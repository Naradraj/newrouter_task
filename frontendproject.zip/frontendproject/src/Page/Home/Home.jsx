import React, { useEffect, useState } from 'react'
import './style.css'
import { Link } from 'react-router-dom';

import axios from 'axios';


export default function Home() {

    let [alldata, setalldata] = useState('');

    let getalldata = () => {

        axios.get('https://api.tvmaze.com/search/shows?q=all')
            .then(function (res) {
                return res;
            })
            .then(function (finalres) {
                setalldata(finalres.data);
            })
            .catch(function (error) {
                console.log(error);
            })

    }
    useEffect(() => {
        getalldata();
        
    }, [])

    console.log(alldata)

    // faq 
    let faqDiv = [

        {
            'question': 'What is javascript ?',
            'answer': 'lorem ispsum'
        },
        {
            'question': 'What is PHP ?',
            'answer': 'lorem ispsum'
        },
        {
            'question': 'What is CSS ?',
            'answer': 'lorem ispsum'
        },
        {
            'question': 'What is NODE JS?',
            'answer': 'lorem ispsum'
        }


    ]

    // usercontext 


    
    

    return (
        <>
            


         
            {/* course section */}
            <section className="container-fluid course_sec">
                <div className="container course_container">
                    <h2 className='text-center'>Movies</h2>
                    <p>Explore Our Live Online Movies</p>
                    <div className="row">

                            {alldata.length>0
                            ?
                            alldata.map((vl,i)=>{
                                console.log(vl.show.image?.medium)
                                return(
                                    <div className="col-lg-3">
                                    <div className="courseName">
                                        <div className="courseImg">
                                            <img src={vl.show.image?.medium} alt="" />
                                        </div>
                                        <div className="courseContent">
                                            <h3 className='mb-1' >{vl.show.name} </h3>
                                            <p>{vl.show.language}</p>
                                            <button className='btn_view '>  <Link to={`/product/${vl.score}`}> view </Link></button>
                                        </div>
                                    </div>
                                </div>
                        
                                )
                            })
                            :
                            <h3>Data Not found</h3>
                            }
                              
                                   
                         

                    </div>
                 
                        <div className="btndiv">
                            <button><Link to={'/courses'}> View More</Link></button>
                        </div>
                     

                </div>
            </section>
            {/* course section */}







            
        </>
    )
}
