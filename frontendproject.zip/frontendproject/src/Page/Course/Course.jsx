import React, { useEffect, useState } from 'react'
import './style.css';
import { Link, useLocation, useParams } from 'react-router-dom';
import axios from 'axios';


export default function Course() {

  let currentId = useLocation();
  let currentPath = currentId.pathname;
  let productid = currentPath.split('/');
  let finalproductid = productid[productid.length - 1];
  console.log(finalproductid);
  
  let [pDetails, setpDetails] = useState([]);
  
  

  useEffect(() => {

    fetch('https://api.tvmaze.com/search/shows?q=all')
    .then(response => response.json())
    .then(data => {
      setpDetails(data);
    })
    .catch(error => console.error('Error fetching data:', error));

  }, [])


  console.log(pDetails)

  // for(var i=0;i<pDetails.length;i++){
  //   console.log(i)
  // }

  return (
    <>
      {/* {pDetails.length>0
      ?
      pDetails.map((vll,i)=>{
        return(
          <p>{vll}</p>
        )
      })
      :
      ""
      } */}

<ul>
        {pDetails.map(show => (
          <li key={(show.show.id===finalproductid ? show.show.id : "not match")}>
            <p>{show.show.name}</p>
            <p>{(show.show.id===finalproductid ? show.show.id : "not match")}</p>
            <p>Score: {show.score}</p>
            {/* Render other properties as needed */}
          </li>
        ))}
      </ul>

      <section className="container-fluid moviesDetailSec">
        <div className="container">
          <h2>
            Movies Name
            {/* {pDetails.show.name} */}
            </h2>
          <div className="row">

            <div className="col-lg-4">
              <div className="innerDivimages">
                {/* <img src={pDetails.show.image?.original} alt="" /> */}
              </div>
            </div>
            <div className="col-lg-6">
              <div className="innerDivContent">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque aliquam recusandae velit pariatur ipsam deserunt molestias quisquam enim, porro quia sit dolor eos dolores sapiente eum voluptatem totam nisi minus.</p>
                <p>Score :</p>
                <p>Runtime : </p>
                <p>Language : </p>
                <p>Rating : </p>
                <button><Link to={''}>Click Me</Link></button>
                {/* <p>{pDetails.show.summary}</p> */}
              </div>
            </div>
          </div>
        </div>
      </section>


    </>
  )
}
